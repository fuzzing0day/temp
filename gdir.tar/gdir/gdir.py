#!/usr/bin/env python
# encoding: utf-8

'''
	多线程并行计算，Queue.get_nowait()非阻塞
		* 生成线程数组
		* 启动线程组
		* 线程组遍历，使每个独立的线程join()，等待主线程退出后，再进入主进程
'''

import json
import sys
import libs.requests as requests
from libs.output import *
from libs.utils.FileUtils import FileUtils
import threading
import Queue
import time
import requests
import chardet
import MySQLdb
import socket

# 全局配置
socket.setdefaulttimeout(10)
otherStyleTime = time.strftime('%Y-%m-%d',time.localtime(time.time()))
tempfile="/tmp/webdir_"+otherStyleTime
clogfile="webdir_"+otherStyleTime+".log"
Fwebdir_result="webdir_result.tmp"
using_dic = './dics/Gdirs.txt' # 使用的字典文件
threads_count = 15 # 线程数
timeout = 10 # 超时时间

def dir_check(url):
	return requests.get(url,timeout=3)

class WyWorker(threading.Thread):

	# 线程初始化，使用OOP传递参数
	def __init__(self,queue):
		threading.Thread.__init__(self)
		self.queue = queue
		self.output = CLIOutput()

	def run(self):
		file_object = open('info.dirlist', 'a')
		while True:
			if self.queue.empty():
				break
			# 用hack方法，no_timeout读取Queue队列，直接异常退出线程避免阻塞
			try:
				url = self.queue.get_nowait()
				#print "gggggggggggggggg",url
				results = dir_check(url)
				if(results.status_code == requests.codes.ok and results.url==url):
					file_object.writelines(url+"\r\n")
				msg = "[%s]:%s \n" % (results.status_code, results.url)
				self.output.printInLine(msg)
			except Exception, e:
				print e # 队列阻塞
				break
 
def fuzz_start(siteurl, file_ext):

	output = CLIOutput()

	print "fuck"
	print siteurl
	global dir_exists
	dir_exists = []

	# 生成队列堆栈
	queue = Queue.Queue()

	for line in FileUtils.getLines(using_dic):
		line = '%s/%s' % (siteurl.rstrip('/'), line.replace('%EXT%', file_ext))
		print line
		queue.put(line)

	output.printHeader('-' * 60)
	output.printTarget(siteurl)
	#output.printConfig(file_ext, str(threads_count), str(queue.qsize()))
	#output.printHeader('-' * 60)

	# 初始化线程组
	threads = []
	for i in xrange(threads_count):
		threads.append(WyWorker(queue))
	# 启动线程
	for t in threads:
		t.start()
	# 等待线程执行结束后，回到主线程中
	for t in threads:
		t.join()

	output.printHeader('-' * 60)
	for url in dir_exists:
		output.printWarning(url)
	output.printHeader('-' * 60)
	
if __name__ == "__main__":
	if len(sys.argv) == 2:
		f=open(sys.argv[1])
		line=f.readline()
		while line:
			print line
			line=line.strip('\n')
			line=line.split(' ')
			testurl=line[0]+"/f0o0o0okFw"
			print testurl
			try:
				fuckfw=requests.get(testurl,timeout=3)
                        except Exception,ex:
                                print "open  error!!!"+str(ex)
                        try:
				if(fuckfw.status_code==404):
					fuzz_start(line[0].strip(), 'php')
			except Exception,ex:
				print "dirscan  is error!!!"+str(ex)
			line = f.readline()
		f.close()
		sys.exit(0)
	else:
		print ("usage: %s start" % sys.argv[0])
		sys.exit(-1)
