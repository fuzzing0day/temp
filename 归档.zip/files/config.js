/* 公共页 seajs 配置和其它参数配置 */
+function () {
    var d = (new Date).getDate();
    seajs.config(SEA_CONFIG);
}();